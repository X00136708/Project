package com.example.nfcproject;

import androidx.fragment.app.Fragment;

class PlaceholderFragment extends Fragment {
}
